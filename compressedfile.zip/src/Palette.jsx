import React, { useState } from 'react';
import './Palette.css';

function Palette() {
  const [colors, setColors] = useState(generateInitialColors(5));

  // Function to generate random hex color
  function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }

  // Generate an initial palette of 5 colors
  function generateInitialColors(num) {
    const colorArray = [];
    for (let i = 0; i < num; i++) {
      colorArray.push({ color: getRandomColor(), locked: false });
    }
    return colorArray;
  }

  // Function to add a new color to the palette
  function addColor() {
    if (colors.length < 10) { // Restrict the maximum number of colors to 10
      setColors([...colors, { color: getRandomColor(), locked: false }]);
    }
  }

  // Function to remove a color from the palette
  function removeColor() {
    if (colors.length > 2) { // Restrict the minimum number of colors to 2
      setColors(colors.slice(0, -1));
    }
  }
  function shuffleColors() {
    let shuffledColors;
    do {
      shuffledColors = [...colors].sort(() => Math.random() - 0.5);
    } while (JSON.stringify(shuffledColors) === JSON.stringify(colors));
    setColors(shuffledColors);
  }

  return (
    <div className="palette-container">
      <div className="palette">
        {colors.map((colorObj, index) => (
          <div
            key={index}
            className="color-box"
            style={{ backgroundColor: colorObj.color }}
          />
        ))}
      </div>
      <div className="buttons">
        <button className="add-color" onClick={addColor}>+</button>
        <button className="remove-color" onClick={removeColor}>-</button>
      </div>
      <div className="buttons">
      <button className="shuffle-color" onClick={shuffleColors}>⟳</button>
      </div>

    </div>
  );
}

export default Palette;
